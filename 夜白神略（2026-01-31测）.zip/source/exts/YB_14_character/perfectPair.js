import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export {perfectPair}

const perfectPair = {//珠联璧合
    wangbi:['caocao'],
}
