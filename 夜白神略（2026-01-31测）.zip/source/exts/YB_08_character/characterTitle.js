import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterTitle }

const characterTitle = {//称号
	ybmjz_caocao:'<font color=cyan></font>', 
	ybmjz_simayi:'<font color=cyan></font>', 
	ybmjz_xiahoudun:'<font color=cyan></font>', 
	ybmjz_zhangliao:'<font color=cyan></font>', 
	ybmjz_xuzhu:'<font color=cyan></font>', 
	ybmjz_guojia:'<font color=cyan></font>', 
	ybmjz_zhenji:'<font color=cyan></font>', 

	ybmjz_liubei:'<font color=cyan></font>', 
	ybmjz_guanyu:'<font color=cyan></font>', 
	ybmjz_zhangfei:'<font color=cyan></font>', 
	ybmjz_zhugeliang:'<font color=cyan></font>', 
	ybmjz_zhaoyun:'<font color=cyan></font>', 
	ybmjz_machao:'<font color=cyan></font>', 
	ybmjz_huangyueying:'<font color=cyan></font>', 

	ybmjz_sunquan:'<font color=cyan></font>', 
	ybmjz_ganning:'<font color=cyan></font>', 
	ybmjz_lvmeng:'<font color=cyan></font>', 
	ybmjz_huanggai:'<font color=cyan></font>', 
	ybmjz_zhouyu:'<font color=cyan></font>', 
	ybmjz_daqiao:'<font color=cyan></font>', 
	ybmjz_luxun:'<font color=cyan></font>', 
	ybmjz_sunshangxiang:'<font color=cyan></font>', 

	ybmjz_huatuo:'<font color=cyan></font>', 
	ybmjz_lvbu:'<font color=cyan></font>', 
	ybmjz_diaochan:'<font color=cyan></font>', 

	ybmjz_liuyan:'<font color=cyan></font>',
	ybmjz_zhangqiying:'<font color=cyan></font>',//张琪瑛
	ybmjz_shen_zhugeliang:'<font color=cyan></font>',//诸葛亮
	ybmjz_majun:'<font color=cyan></font>',//马钧
	ybmjz_sunluyu:'<font color=cyan></font>',//孙鲁育
}