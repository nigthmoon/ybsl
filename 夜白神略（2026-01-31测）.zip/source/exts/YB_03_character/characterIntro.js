import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterIntro }

const characterIntro = {

	cszmj_ybxh_liulei:'刘磊',
	cszmj_ybxh_zhaoyanyan:'赵颜妍',
	cszmj_ybxh_xuqingwei:'徐庆伟',
	cszmj_ybxh_yanwang:'阎王',
	





































	ssj_ybxh_linyi:'林逸，自己百度吧，又臭又长，懒得整理了。',
	ssj_ybxh_lindongfang:'在校花的贴身高手中登场于第1章，在很纯很暧昧中登场于第x章。等补完很纯再补。',
	ssj_ybxh_wangxinyan:'王心妍',
	ssj_ybxh_chumengyao:'楚梦瑶',
	ssj_ybxh_chenyushu:'陈雨舒',
	ssj_ybxh_chupengzhan:'楚鹏展',
	ssj_ybxh_lifu:'李福',//福立
	ssj_ybxh_zhongpinliang:'钟品亮',
	ssj_ybxh_weiwujiangjun:'威武将军',
	ssj_ybxh_zhangnaipao:'张乃炮',
	ssj_ybxh_gaoxiaofu:'高小福',
	ssj_ybxh_wangzhifeng:'王智峰，出自《校花的贴身高手》，首登场第20章。故事发生所在高中的教导主任。因林逸来找他时，正在和情人在办公室云雨，被林逸听到。不过林逸高情商表示：啥也没听到。王智峰知道被捏住了小辫子，于是后面剧情基本偏向林逸。（想不到吧，这货最后一次登场是在2696章，基本是个究极背景板，没有哪个龙套比他还有牌面）',
	ssj_ybxh_zouruoming:'邹若明',
	ssj_ybxh_kangxiaobo:'康晓波',
	ssj_ybxh_zhongfabai:'钟发白',//钟品亮父亲
	//第25章康晓波的介绍中，提及的是钟三国
	
	
	
	ssj_ybxh_jiaoyazi:'焦牙子',
	ssj_ybxh_yewaner:'夜婉儿',
	ssj_ybxh_ergoudan:'二狗蛋',


	ssj_ybxh_zhanglongliyao:'张龙，李妖，出自《校花的贴身高手》第166，167章前后。受李呲花指示，二人意欲驾驶面包车创死林逸，结果被林逸鞋尖藏刀片踢爆轮胎，二人的车翻下山崖，一命呜呼。（小说情节需要，主角神功护体，请勿现实模仿）',
	
	ssj_ybxh_yukun:'雨坤',
















}