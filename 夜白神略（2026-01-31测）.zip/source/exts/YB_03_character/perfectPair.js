import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export {perfectPair}

const perfectPair = {}
