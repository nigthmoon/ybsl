import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterSort }

const characterSort = {
	ybxh:{
		ssj_ybxh_ssj:[
			'ssj_ybxh_linyi','ssj_ybxh_zhanglongliyao','ssj_ybxh_wangzhifeng',
		],
	},

}
