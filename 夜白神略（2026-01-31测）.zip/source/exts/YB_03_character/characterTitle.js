import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterTitle }

const characterTitle = {//称号
	'ssj_ybxh_linyi':'校花的贴身高手',
	'ssj_ybxh_zhanglongliyao':'校花的贴身高手',
	ssj_ybxh_wangzhifeng:'校花的贴身高手',
}