import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { dynamicTranslate }

const dynamicTranslate = {
	ybsl_magicSkill:function(player){

    },
	ybsl_spMagicSkill:function(player){
        
    },
    // "YB_nobody_guiyin":function(player){
    //     var players=game.filterPlayer(function(current){
    //         return current!=player&&current.inRange(player);
    //     });
    //     if(players.length!=1)return '锁定技，若攻击范围内包含你的角色数量为1，则其获得牌时你摸等量的牌，<span class=thundertext>否则你使用基本牌或普通锦囊牌时结算两次且可以额外指定任意名角色为目标。</span>';
    //     else return '锁定技，若攻击范围内包含你的角色数量为1，<span class=thundertext>则其（'+get.translation(players[0])+'）获得牌时你摸等量的牌</span>，否则你使用基本牌或普通锦囊牌时结算两次且可以额外指定任意名角色为目标。';
    // },
}