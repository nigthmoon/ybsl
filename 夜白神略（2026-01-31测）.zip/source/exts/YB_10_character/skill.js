import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { skill }

/** @type { importCharacterConfig['skill'] } */
const skill = {
	ybsl_magicSkill:{
		
	},
	ybsl_spMagicSkill:{

	},
}