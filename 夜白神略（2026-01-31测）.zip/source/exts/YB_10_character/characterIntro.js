import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterIntro }

const characterIntro = {
	
}