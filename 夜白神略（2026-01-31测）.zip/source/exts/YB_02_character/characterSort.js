import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterSort }

const characterSort = {
	ybart:{
		'ybsl_sixp':[
			'ybart_013yinji','ybart_014liutianyu','ybart_016manchengqi','ybart_017xiaohong','ybart_041mmuqin'
		],
	},

}
