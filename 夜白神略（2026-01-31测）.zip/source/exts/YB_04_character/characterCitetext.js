import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterCitetext }

const characterCitetext = {
	
}