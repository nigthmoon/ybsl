import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterSort }

const characterSort = {
	sgstrxs:{
		sgskjdbzjms:[
			'sgskjdbzjms_zrshenmoyi','sgskjdbzjms_zrzhenghao',




			'sgskjdbzjms_mo_zhoutai','sgskjdbzjms_shen_zhugeliang',
			'sgskjdbzjms_leizhenzi','sgskjdbzjms_xian_zhugeguo',
			'sgskjdbzjms_zhen_zhangfei','sgskjdbzjms_zhen_guanyu',
			'sgskjdbzjms_shen_liubei','sgskjdbzjms_zhen_machao',
			'sgskjdbzjms_zhen_liubei',
		],
		qmsgswkjsgj:[
			'qmsgswkjsgj_re_xizhicai','qmsgswkjsgj_re_liuxie',
			'qmsgswkjsgj_shen_zhaoyun','qmsgswkjsgj_gui_xuyou',
			'qmsgswkjsgj_gui_zhaoyun','qmsgswkjsgj_gui_sunquan',
			'qmsgswkjsgj_shen_guojia','qmsgswkjsgj_re_sp_duyu',
			'qmsgswkjsgj_gui_liubei','qmsgswkjsgj_shen_zhugeliang',
			'qmsgswkjsgj_gui_re_zhouyu','qmsgswkjsgj_sb_huangzhong',
			'qmsgswkjsgj_re_yangbiao','qmsgswkjsgj_re_luotong',
			'qmsgswkjsgj_re_liuyan','qmsgswkjsgj_re_lusu',
			'qmsgswkjsgj_re_caorui','qmsgswkjsgj_re_caiwenji',
			'qmsgswkjsgj_re_zhangxiu','qmsgswkjsgj_re_fuhuanghou',
			'qmsgswkjsgj_shen_ganning','qmsgswkjsgj_re_sunhanhua',
			'qmsgswkjsgj_re_shen_zhaoyun','qmsgswkjsgj_yingtian_simayi',
			'qmsgswkjsgj_shen_lusu','qmsgswkjsgj_re_sunquan',
			'qmsgswkjsgj_shen_zhouyu','qmsgswkjsgj_shen_xunyu',
			'qmsgswkjsgj_mb_luyusheng','qmsgswkjsgj_shen_luxun',
			'qmsgswkjsgj_shen_caocao','qmsgswkjsgj_shen_lvbu',
			'qmsgswkjsgj_pot_weiyan','qmsgswkjsgj_pot_taishici',
			'qmsgswkjsgj_re_caopi','qmsgswkjsgj_re_shamoke',
			'qmsgswkjsgj_re_peixiu','qmsgswkjsgj_re_shichangshi',
			'qmsgswkjsgj_re_jushou','qmsgswkjsgj_shen_huatuo',
			'qmsgswkjsgj_pot_yuji','qmsgswkjsgj_re_mb_caomao',
			'qmsgswkjsgj_shen_sunce',
			'qmsgswkjsgj_mb_sunluyu','qmsgswkjsgj_re_mb_zhangzhi',
			'qmsgswkjsgj_shen_taishici',



			'qmsgswkjsgj_re_zhangxuan','qmsgswkjsgj_re_chenshi',
			'qmsgswkjsgj_re_dc_tengfanglan','qmsgswkjsgj_re_zhenghun',
			'qmsgswkjsgj_re_re_liuzan','qmsgswkjsgj_re_wupu',
			'qmsgswkjsgj_re_ruanyu','qmsgswkjsgj_re_dc_duyu',
			'qmsgswkjsgj_re_star_caoren','qmsgswkjsgj_re_dc_xiahouhui',
			'qmsgswkjsgj_re_panghong','qmsgswkjsgj_re_zhujianping',
			'qmsgswkjsgj_re_guotiying','qmsgswkjsgj_re_caofang',
			'qmsgswkjsgj_re_guozhao','qmsgswkjsgj_re_caomao',


			'qmsgswkjsgj_mengpo',

			//神赐
			'qmsgswkjsgj_shenci_wu_zhugeliang','qmsgswkjsgj_shenci_re_duyu',
			'qmsgswkjsgj_shenci_wu_luxun','qmsgswkjsgj_shenci_sb_caopi',
			'qmsgswkjsgj_shenci_re_sunhanhua','qmsgswkjsgj_shenci_dc_zhouxuān',
			'qmsgswkjsgj_shenci_caomao','qmsgswkjsgj_shenci_pot_yuji',
		],
		sgsxjxfzmnl:[
			'sgsxjxfzmnl_re_xusheng','sgsxjxfzmnl_sb_huangzhong',
			'sgsxjxfzmnl_shen_sunce','sgsxjxfzmnl_sb_xiahoushi',
			'sgsxjxfzmnl_miheng','sgsxjxfzmnl_wangyuanji',
			'sgsxjxfzmnl_shen_guojia','sgsxjxfzmnl_wenyang',
			'sgsxjxfzmnl_re_jushou','sgsxjxfzmnl_shen_ganning',
			'sgsxjxfzmnl_shichangshi','sgsxjxfzmnl_yue_caiwenji',
			'sgsxjxfzmnl_liuyan','sgsxjxfzmnl_shen_xunyu',
			'sgsxjxfzmnl_shen_zhangfei','sgsxjxfzmnl_wu_zhugeliang',
			'sgsxjxfzmnl_sb_caopi','sgsxjxfzmnl_boss_zhaoyun',
			'sgsxjxfzmnl_nanhualaoxian',
			'sgsxjxfzmnl_zhangxuan','sgsxjxfzmnl_caojinyu',
			'sgsxjxfzmnl_shen_machao','sgsxjxfzmnl_sunhanhua',
			'sgsxjxfzmnl_xin_guozhao','sgsxjxfzmnl_sb_guanyu',
			'sgsxjxfzmnl_sb_huanggai','sgsxjxfzmnl_dc_zhouxuān',
			'sgsxjxfzmnl_sunlingluan','sgsxjxfzmnl_xushao',
			'sgsxjxfzmnl_sp_huaman','sgsxjxfzmnl_quyi',
			'sgsxjxfzmnl_shen_jiangwei','sgsxjxfzmnl_dc_liuye',
			'sgsxjxfzmnl_peixiu','sgsxjxfzmnl_wu_luxun',
			'sgsxjxfzmnl_mb_caomao','sgsxjxfzmnl_puyuan',
			'sgsxjxfzmnl_dc_shen_huatuo','sgsxjxfzmnl_dc_xujing',
			'sgsxjxfzmnl_shen_zhangjiao','sgsxjxfzmnl_xizhicai',
			'sgsxjxfzmnl_sb_sp_zhugeliang','sgsxjxfzmnl_dc_qinghegongzhu',
			'sgsxjxfzmnl_bianxi','sgsxjxfzmnl_shen_sunquan',
			'sgsxjxfzmnl_panshu','sgsxjxfzmnl_haozhao',
			'sgsxjxfzmnl_fuqian','sgsxjxfzmnl_sb_caoren',
			'sgsxjxfzmnl_yue_miheng','sgsxjxfzmnl_zhujianping',
			'sgsxjxfzmnl_shen_huangzhong','sgsxjxfzmnl_dc_tengfanglan',
			'sgsxjxfzmnl_sb_diaochan','sgsxjxfzmnl_re_zuoci',
			'sgsxjxfzmnl_chengui','sgsxjxfzmnl_dc_sunru',
			'sgsxjxfzmnl_yue_xiaoqiao','sgsxjxfzmnl_dc_sb_simayi',
			'sgsxjxfzmnl_mb_zhangfen','sgsxjxfzmnl_liuzan',
			'sgsxjxfzmnl_xurong','sgsxjxfzmnl_dc_sb_huanggai',
			'sgsxjxfzmnl_yuanyin','sgsxjxfzmnl_v_zhangliao',
			'sgsxjxfzmnl_ol_nanhualaoxian',
			'sgsxjxfzmnl_dc_sb_zhouyu','sgsxjxfzmnl_dc_simashi',
			'sgsxjxfzmnl_xuelingyun','sgsxjxfzmnl_yangbiao',
			'sgsxjxfzmnl_mb_simazhao','sgsxjxfzmnl_caoying',



			'sgsxjxfzmnl_scs_zhangrang','sgsxjxfzmnl_scs_zhaozhong',
			'sgsxjxfzmnl_scs_sunzhang','sgsxjxfzmnl_scs_bilan',
			'sgsxjxfzmnl_scs_xiayun','sgsxjxfzmnl_scs_hankui',
			'sgsxjxfzmnl_scs_lisong','sgsxjxfzmnl_scs_duangui',
			'sgsxjxfzmnl_scs_guosheng','sgsxjxfzmnl_scs_gaowang',

			'sgsxjxfzmnl_mo_diaochan','sgsxjxfzmnl_mo_lvbu',
			'sgsxjxfzmnl_mo_caopi','sgsxjxfzmnl_mo_guanyu',
			'sgsxjxfzmnl_mo_re_diaochan','sgsxjxfzmnl_mo_zhangfei',
			'sgsxjxfzmnl_mo_jiaxu','sgsxjxfzmnl_mo_guosi',
			'sgsxjxfzmnl_mo_zhangji',
		],
		zzrsqlkjygzz:[
			'zzrsqlkjygzz_shen_guanyu','zzrsqlkjygzz_shen_zhangjiao',
			'zzrsqlkjygzz_shen_sunce',
			'zzrsqlkjygzz_re_zuoci',
			'zzrsqlkjygzz_yi_caocao','zzrsqlkjygzz_yi_guanyu',
			'zzrsqlkjygzz_yi_zhangjiao','zzrsqlkjygzz_yi2_zhangjiao','zzrsqlkjygzz_yi3_zhangjiao',
			'zzrsqlkjygzz_yi_luxun','zzrsqlkjygzz_yi_sunce',
			'zzrsqlkjygzz_yao_zhoutai',
		],
	}
}
