import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterTitle }

const characterTitle = {//称号
	North_yanghuiyu:'<font color=cyan></font>',
	North_duyu:'<font color=cyan></font>',
	North_sunshangxiang:'<font color=cyan></font>',
	Northxx_sunshangxiang:'<font color=cyan></font>',
	North_zhugeliang:'<font color=cyan></font>',
	Northxx_zhugeliang:'<font color=cyan></font>',
	North_lidian:'<font color=cyan></font>',
	North_shamoke:'<font color=cyan></font>',
	North_diaochan:'<font color=cyan></font>',
	North_beimihu:'<font color=cyan></font>',
	North_bulianshi:'<font color=cyan></font>',
	North_caojinyu:'<font color=cyan></font>',
	North_huangyueying:'<font color=cyan></font>',

	ybsl_mystery1:'<font color=cyan></font>',
	North_pc:'<font color=cyan></font>',

	North_caoxiancaohua:'<font color=cyan></font>',
	North_sunhanhua:'<font color=cyan></font>',
	North_guozhao:'<font color=cyan></font>',
	North_zhaoxiang:'<font color=cyan></font>',
	North_liufeng:'<font color=cyan></font>',

	"YB_nobody_simayi":'<font color=cyan></font>',
	"YB_nobody_zhaoyun":'<font color=cyan></font>',
}