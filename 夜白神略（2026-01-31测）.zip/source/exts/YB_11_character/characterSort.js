import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterSort }

const characterSort = {
	yhky:{
		yhky_wei:[
			'yhky_caoying',
		],
		yhky_shu:[
			'yhky_shlizhaoyi',
		],
		yhky_wu:[
	
		],
		yhky_qun:[
			'yhky_diaochan',
		],
		yhky_jin:[
			
		],
		yhky_shen:[
			
		],
	}

}
