import { lib, game, ui, get, ai, _status } from '../../../../noname.js';
// export const type = "mode";
// /**
//  * @type { () => importModeConfig }
//  */
// export default sgstrxs = () => {
//     return {
//         name: 'sgstrxs',
//         game:{

//         },
//     }
// }
// var sgstrxs = function () {
//     game.addMode(
//         'sgstrxs',
//         {},
//         {
//             translate:'三国杀同人小说'
//         },
//     )
// }
// export default sgstrxs;