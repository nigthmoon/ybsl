import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterUndertext ,accessoryPacket}

const characterUndertext = {
		
	ybsl_wangbi:'忠能勤事，心如铁石，国之良吏也。<br>--曹操',
	ybnb_wangbi:'忠能勤事，心如铁石，国之良吏也。<br>--曹操',
	
}
const accessoryPacket = {
	
}