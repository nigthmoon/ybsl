import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterTitle }

const characterTitle = { //称号
	// ybsl_xuyou: '夜白设计',
	// ybsl_pujing: '夜白设计',
	// ybsl_lvyi: '汉尚书令',
	// ybsl_yinfan: '啼血的谍客',
	// ybsl_shlizhaoyi: '抗拒火环',
	// ybsl_sunsháo: '知而后动',
	// ybsl_wangbi: '倾厦之梁',
	// ybnb_wangbi: '倾厦之梁',
	// ybsl_jiangziwen:'骨清为神',
	// ybsl_suojing: '铜驼荆棘',
	// ybsl_wangpou:'闻雷泣墓',
	// ybsl_yangxu:'悬鱼太守',
	// ybsl_shichong:'蜡炬作炊',

	// Fe2O3_duqiong:'蜀之球琳',
}