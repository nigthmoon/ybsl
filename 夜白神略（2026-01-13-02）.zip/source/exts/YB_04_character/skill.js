import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
import { precontent } from '../../packages/precontent.js';
export { skill }

/** @type { importCharacterConfig['skill'] } */
const skill = {
	

}
