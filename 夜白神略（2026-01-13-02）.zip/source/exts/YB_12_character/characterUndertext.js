import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterUndertext , accessoryPacket }

const characterUndertext = {
    qmsgswkjsgj_re_xizhicai:'“随便换目标的戏志才是什么人渣？”<br>——琉紫苑',
    // sgsxjxfzmnl_sb_caopi:'',
}
const accessoryPacket = {}