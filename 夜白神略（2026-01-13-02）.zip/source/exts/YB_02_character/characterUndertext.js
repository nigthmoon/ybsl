import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterUndertext }

const characterUndertext = {
	//理论上这里是六艺篇的武将信息，但六艺篇的武将本质上还是夜白神略本体包，所以就放在了YB_1里了
}