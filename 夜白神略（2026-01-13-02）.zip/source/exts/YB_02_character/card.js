import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export {card};
/** @type { importCharacterConfig['card'] } */
const card = {
	'ybmyx_moon':{
		fullskin:true,
	},
	'ybmyx_clam':{
		fullskin:true,
	},
	'ybmyx_lightning':{
		fullskin:true,
	},
	'ybmyx_wind':{
		fullskin:true,
	},
	'ybmyx_flame':{
		fullskin:true,
	},
}