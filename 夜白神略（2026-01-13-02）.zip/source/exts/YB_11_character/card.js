import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export {card};
/** @type { importCharacterConfig['card'] } */
const card = {
	
};
// if(player&&player.name1&&lib.characterLightext&&lib.characterLightext[player.name1]&&lib.characterLightext[player.name1](player)){
// 	var ybstr = lib.characterLightext[player.name1](player)[lib.characterLightext[player.name1](player).length-1]
// 	// ui.create.div(".xcaption", "武将缘分", rightPane.firstChild);
// 	ui.create.div(".xskill", ybstr, rightPane.firstChild)
// 	// ui.create.div(".xskill","<div data-color>" + ybstr+ "</div>", rightPane.firstChild)
// }