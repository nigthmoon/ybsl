import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterTitle }

const characterTitle = {//称号
	yhky_shlizhaoyi:'<font color=cyan></font>',
	yhky_caoying:'<font color=cyan></font>',
	yhky_diaochan:'<font color=cyan>绝世之舞</font>',
}