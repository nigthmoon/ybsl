import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterCitetext }

const characterCitetext = {
    // qmsgswkjsgj_gui_xuyou:'主角的许攸，意外得到了白无常赐福，获得了暴敛，且未被鬼邪侵染，反而加了一点体力上限。',
    // qmsgswkjsgj_gui_zhaoyun:'持有者王洋，剧情中，被白无常赐福，获得暴敛，且变为鬼势力。',
    // qmsgswkjsgj_gui_sunquan:'主角神郭嘉挑战百胜的最后一胜的狙击仔。',
}