import { lib, game, ui, get, ai, _status } from '../../../../../noname.js'
export { characterIntro }

const characterIntro = {
	ybsl_windmoon:'夜白自己的风灵月影，专门作为测试未登场技能的载体。',
}